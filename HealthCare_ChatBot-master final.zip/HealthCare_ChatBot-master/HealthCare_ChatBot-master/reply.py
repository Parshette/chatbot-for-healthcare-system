all_response_msg = { "greeting" : ["Hello, thanks for asking", "Good to see you again", "Hi there, how can I help?"],
      "goodbye": ["See you!", "Have a nice day", "Bye! Come back again soon."],
      "thanks": ["Happy to help!", "Any time!", "My pleasure"],
      "noanswer": ["Sorry, can't understand you", "Please give me more info", "Not sure I understand"],
      "options": ["I can help you diagonose the illlness, what precuations to take and respective Doctor, Hospitals and Pharmacies"],
    }